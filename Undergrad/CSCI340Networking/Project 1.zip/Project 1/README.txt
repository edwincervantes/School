
-Recommended to compile and run through terminal. Made and tested on a Linux machine with Mozilla Firefox.
- ~$ python ./WebServerLab.py
-May need to run on sudo
-In browser of your choice navigate to host IP followed by port number (8888) and then the html file you wish to view
- HOST:8888/HelloWorld.html
-This should produce "Hola Mundo" to the screen
-Any other version of HOST:8888 will produce a 404 not found error.
