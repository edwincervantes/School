/*This program is used to print the below text*/
package main

import "fmt" //import fmt

func main() {
	fmt.Printf("Good morning CSCI340\n")
}

