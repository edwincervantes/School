import matplotlib.pyplot as plt
import numpy as np

# Load the data from the file
exponents, intervals, errors, times = np.loadtxt("pi_results.txt", skiprows=1, unpack=True)

# Plot Error vs. Exponent
plt.figure(figsize=(10, 5))

plt.subplot(1, 2, 1)
plt.plot(exponents, errors, marker='o', linestyle='-')
plt.yscale("log")  # Log scale for error
plt.xlabel("Exponent (10^x intervals)")
plt.ylabel("Error (log scale)")
plt.title("Accuracy of Approximation")
plt.subplot(1, 2, 2)
plt.plot(exponents, times, marker='o', linestyle='-')
plt.xlabel("Exponent (10^x intervals)")
plt.ylabel("Time (sec)")
plt.title("Computation Time for Approximation")
plt.tight_layout()
plt.show()
